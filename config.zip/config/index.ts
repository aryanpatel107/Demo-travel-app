
import { wanderlyConfig } from "./wanderly";
import { travelproConfig } from "./travelpro";
import { mytravelConfig } from "./mytravel";
import type { BrandConfig } from "./types";

export type BrandName = "wanderly" | "travelpro" | "mytravel";

const brandMap: Record<BrandName, BrandConfig> = {
  wanderly: wanderlyConfig,
  travelpro: travelproConfig,
  mytravel: mytravelConfig,
};

/**
 * Resolve the internal application brand from a remote website name.
 *
 * The external Technoheaven API uses website names such as:
 *
 *   Tripgoasia
 *   Gujjutours
 *   MyTravel
 *
 * Our existing application internally uses:
 *
 *   travelpro
 *   wanderly
 *   mytravel
 */
export function resolveRemoteBrandKey(
  websiteName: string | null | undefined
): BrandName | null {
  const normalized = websiteName
    ?.trim()
    .toLowerCase()
    .replace(/[\s_-]+/g, "");

  if (!normalized) {
    return null;
  }

  if (
    normalized.includes("tripgoasia") ||
    normalized.includes("travelpro")
  ) {
    return "travelpro";
  }

  if (
    normalized.includes("gujjutours") ||
    normalized.includes("wanderly")
  ) {
    return "wanderly";
  }

  if (normalized.includes("mytravel")) {
    return "mytravel";
  }

  return null;
}

/**
 * Resolve the old environment-based brand value.
 *
 * This is kept only as a FALLBACK for places that still need the
 * static configuration before the remote configuration has loaded.
 *
 * It is no longer the source of truth for the runtime website.
 */
export function resolveEnvironmentBrandKey(
  rawValue?: string | null
): BrandName | null {
  if (!rawValue) {
    return null;
  }

  const normalized = rawValue.trim().toLowerCase();

  if (normalized.includes("wanderly")) {
    return "wanderly";
  }

  if (normalized.includes("travelpro")) {
    return "travelpro";
  }

  if (normalized.includes("mytravel")) {
    return "mytravel";
  }

  return null;
}

/**
 * Get a static configuration by its internal brand key.
 */
export function getStaticBrandConfig(
  brand: BrandName
): BrandConfig {
  return brandMap[brand];
}

/**
 * Static fallback configuration.
 *
 * IMPORTANT:
 * NEXT_PUBLIC_BRAND is no longer required.
 *
 * If it exists, we use it.
 * If it does not exist, TravelPro is used as the safe generic
 * fallback until the remote configuration has loaded.
 */
const environmentBrand =
  resolveEnvironmentBrandKey(
    process.env.NEXT_PUBLIC_BRAND
  );

export const config: BrandConfig =
  environmentBrand
    ? brandMap[environmentBrand]
    : travelproConfig;

