
using Microsoft.AspNetCore.Mvc;

namespace TravelApp.Api.Controllers;

[ApiController]
[Route("api/proxy")]
public class ExternalConfigProxyController : ControllerBase
{
    private readonly IHttpClientFactory _httpClientFactory;

    public ExternalConfigProxyController(IHttpClientFactory httpClientFactory)
    {
        _httpClientFactory = httpClientFactory;
    }

    [HttpGet("brand-config")]
    public async Task<IActionResult> GetBrandConfig(
        [FromQuery] string? hostname,
        [FromQuery] string? lang = "en")
    {
        // Use the hostname supplied by the frontend.
        hostname = hostname?.Trim().ToLowerInvariant();

        if (string.IsNullOrWhiteSpace(hostname))
        {
            return BadRequest(new
            {
                isSuccess = false,
                error = "Hostname is required."
            });
        }

        // Runtime website mapping.
        //
        // Local development:
        // localhost
        //      ↓
        // stagingapi.technoheaven.com
        //      ↓
        // config for stagingb2b.technoheaven.com
        //
        // Production/staging:
        // website hostname
        //      ↓
        // corresponding API
        //      ↓
        // config for that website
        var siteMappings =
            new Dictionary<string, (string ApiBaseUrl, string ConfigHostname)>(
                StringComparer.OrdinalIgnoreCase)
            {
                // Local development
                ["localhost"] = (
                    "https://stagingapi.technoheaven.com",
                    "stagingb2b.technoheaven.com"
                ),

                // Technoheaven B2B
                ["stagingb2b.technoheaven.com"] = (
                    "https://stagingapi.technoheaven.com",
                    "stagingb2b.technoheaven.com"
                ),

                // TripGoAsia / TravelPro
                ["www.tripgoasia.com"] = (
                    "https://stagingapi.tripgoasia.com",
                    "www.tripgoasia.com"
                ),

                // GujjuTours / Wanderly
                ["www.gujjutours.com"] = (
                    "https://stagingapi.gujjutours.com",
                    "www.gujjutours.com"
                )
            };

        // Check whether this hostname is allowed.
        if (!siteMappings.TryGetValue(hostname, out var mapping))
        {
            return BadRequest(new
            {
                isSuccess = false,
                error = $"Hostname '{hostname}' is not configured."
            });
        }

        // Make sure language has a usable value.
        lang = string.IsNullOrWhiteSpace(lang)
            ? "en"
            : lang.Trim();

        // Build the external Technoheaven configuration URL.
        var targetUrl =
            $"{mapping.ApiBaseUrl}/api/core/v1/config/" +
            $"{Uri.EscapeDataString(mapping.ConfigHostname)}" +
            $"?lang={Uri.EscapeDataString(lang)}";

        try
        {
            var httpClient = _httpClientFactory.CreateClient();

            // Request the external configuration API.
            using var response = await httpClient.GetAsync(targetUrl);

            var responseBody = await response.Content.ReadAsStringAsync();

            // Forward the external API's status code and body.
            return new ContentResult
            {
                StatusCode = (int)response.StatusCode,
                Content = responseBody,
                ContentType = response.Content.Headers.ContentType?.ToString()
                    ?? "application/json"
            };
        }
        catch (HttpRequestException ex)
        {
            return StatusCode(StatusCodes.Status502BadGateway, new
            {
                isSuccess = false,
                error = "Unable to connect to the external configuration API.",
                details = ex.Message
            });
        }
        catch (TaskCanceledException ex)
        {
            return StatusCode(StatusCodes.Status504GatewayTimeout, new
            {
                isSuccess = false,
                error = "The external configuration API request timed out.",
                details = ex.Message
            });
        }
        catch (Exception ex)
        {
            return StatusCode(StatusCodes.Status500InternalServerError, new
            {
                isSuccess = false,
                error = "An unexpected error occurred while loading website configuration.",
                details = ex.Message
            });
        }
    }
}

