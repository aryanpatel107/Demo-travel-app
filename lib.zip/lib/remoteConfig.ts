export interface RemoteConfig {
  websiteLaunguage?: unknown[];
  websiteRights?: unknown[];
  font?: unknown[];
  colors?: unknown[];
  websiteLinks?: unknown[];
  socialMediaConfig?: unknown[];
  websiteContact?: unknown[];
  websiteModules?: unknown[];
  theme?: unknown;
  recommendations?: unknown[];
  geo?: {
    country?: string | null;
    city?: string | null;
    ip?: string | null;
  } | null;
  websiteConfiguration?: unknown;
  websiteCurrency?: unknown[];
}

export async function fetchRemoteConfig(
  lang = "en"
): Promise<RemoteConfig> {
  const apiBaseUrl = process.env.API_BASE_URL;
  const hostname = process.env.HOSTNAME;

  if (!apiBaseUrl) {
    throw new Error("Missing API_BASE_URL");
  }

  if (!hostname) {
    throw new Error("Missing HOSTNAME");
  }

  const url =
    `${apiBaseUrl}/api/core/v1/config/` +
    `${encodeURIComponent(hostname)}?lang=${encodeURIComponent(lang)}`;

  const response = await fetch(url, {
    cache: "no-store",
  });

  if (!response.ok) {
    throw new Error(
      `Remote configuration request failed: ${response.status}`
    );
  }

  const data = await response.json();

  return data.result ?? data;
}