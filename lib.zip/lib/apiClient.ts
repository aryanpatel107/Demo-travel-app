
import type { RemoteConfigResult } from "@/types/remoteConfig";

const API_BASE_URL =
  process.env.NEXT_PUBLIC_API_URL?.replace(/\/+$/, "") ||
  "http://localhost:5019";

export class ApiError extends Error {
  status: number;
  data: unknown;

  constructor(
    message: string,
    status = 500,
    data: unknown = null
  ) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.data = data;
  }
}

type ApiFetchOptions = RequestInit & {
  skipJsonContentType?: boolean;
};

function getApiUrl(path: string): string {
  if (/^https?:\/\//i.test(path)) {
    return path;
  }

  const normalizedPath = path.startsWith("/") ? path : `/${path}`;

  return `${API_BASE_URL}${normalizedPath}`;
}

async function parseResponseBody(response: Response): Promise<unknown> {
  const contentType = response.headers.get("content-type") ?? "";

  if (contentType.includes("application/json")) {
    try {
      return await response.json();
    } catch {
      return null;
    }
  }

  const text = await response.text();

  if (!text) {
    return null;
  }

  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}

function getErrorMessage(data: unknown, fallback: string): string {
  if (!data || typeof data !== "object") {
    return fallback;
  }

  const record = data as Record<string, unknown>;

  if (typeof record.message === "string" && record.message.trim()) {
    return record.message;
  }

  if (typeof record.error === "string" && record.error.trim()) {
    return record.error;
  }

  if (typeof record.title === "string" && record.title.trim()) {
    return record.title;
  }

  if (
    record.errors &&
    typeof record.errors === "object"
  ) {
    const errors = record.errors as Record<string, unknown>;

    for (const value of Object.values(errors)) {
      if (Array.isArray(value) && value.length > 0) {
        const firstError = value.find(
          (item) => typeof item === "string"
        );

        if (typeof firstError === "string") {
          return firstError;
        }
      }

      if (typeof value === "string" && value.trim()) {
        return value;
      }
    }
  }

  return fallback;
}

/**
 * Generic API request helper.
 *
 * All authenticated requests use credentials: "include" so the
 * ASP.NET Core authentication cookie is sent automatically.
 */
export async function apiFetch<T = unknown>(
  path: string,
  options: ApiFetchOptions = {}
): Promise<T> {
  const {
    headers,
    body,
    skipJsonContentType,
    ...requestOptions
  } = options;

  const requestHeaders = new Headers(headers);

  const isFormData =
    typeof FormData !== "undefined" &&
    body instanceof FormData;

  if (
    body !== undefined &&
    body !== null &&
    !isFormData &&
    !skipJsonContentType &&
    !requestHeaders.has("Content-Type")
  ) {
    requestHeaders.set("Content-Type", "application/json");
  }

  const response = await fetch(getApiUrl(path), {
    ...requestOptions,
    headers: requestHeaders,
    credentials: "include",
    body,
  });

  const data = await parseResponseBody(response);

  if (!response.ok) {
    throw new ApiError(
      getErrorMessage(
        data,
        `API request failed with status ${response.status}.`
      ),
      response.status,
      data
    );
  }

  return data as T;
}

type BrandConfigResponse = {
  isSuccess: boolean;
  result: RemoteConfigResult | null;
  error: string | null;
};

/**
 * Fetch the website configuration for the current hostname.
 *
 * Browser example:
 *
 * www.tripgoasia.com
 *        ↓
 * /api/proxy/brand-config?hostname=www.tripgoasia.com
 *        ↓
 * TravelApp.Api
 *        ↓
 * stagingapi.tripgoasia.com
 */
export async function fetchBrandConfig(
  lang = "en"
): Promise<BrandConfigResponse> {
  try {
    const hostname =
      typeof window !== "undefined"
        ? window.location.hostname
        : "localhost";

    const params = new URLSearchParams({
      hostname,
      lang,
    });

    const response = await apiFetch<unknown>(
      `/api/proxy/brand-config?${params.toString()}`,
      {
        method: "GET",
        cache: "no-store",
      }
    );

    if (
      !response ||
      typeof response !== "object"
    ) {
      return {
        isSuccess: false,
        result: null,
        error: "Invalid configuration response.",
      };
    }

    const data = response as Record<string, unknown>;

    if (
      data.isSuccess === false ||
      !data.result
    ) {
      return {
        isSuccess: false,
        result: null,
        error:
          typeof data.error === "string"
            ? data.error
            : "Website configuration could not be loaded.",
      };
    }

    return {
      isSuccess: true,
      result: data.result as RemoteConfigResult,
      error: null,
    };
  } catch (error) {
    if (error instanceof ApiError) {
      return {
        isSuccess: false,
        result: null,
        error: error.message,
      };
    }

    return {
      isSuccess: false,
      result: null,
      error:
        error instanceof Error
          ? error.message
          : "Unable to load website configuration.",
    };
  }
}

/* -------------------------------------------------------------------------- */
/* Authentication                                                             */
/* -------------------------------------------------------------------------- */

export async function login<T = unknown>(
  payload: unknown
): Promise<T> {
  return apiFetch<T>("/api/auth/login", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export async function register<T = unknown>(
  payload: unknown
): Promise<T> {
  return apiFetch<T>("/api/auth/register", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export async function logout<T = unknown>(): Promise<T> {
  return apiFetch<T>("/api/auth/logout", {
    method: "POST",
  });
}

export async function getCurrentUser<T = unknown>(): Promise<T> {
  return apiFetch<T>("/api/auth/me", {
    method: "GET",
    cache: "no-store",
  });
}

/* -------------------------------------------------------------------------- */
/* Trips                                                                      */
/* -------------------------------------------------------------------------- */

export async function getTrips<T = unknown>(): Promise<T> {
  return apiFetch<T>("/api/trips", {
    method: "GET",
    cache: "no-store",
  });
}

export async function getTrip<T = unknown>(
  tripId: string | number
): Promise<T> {
  return apiFetch<T>(`/api/trips/${tripId}`, {
    method: "GET",
    cache: "no-store",
  });
}

export async function createTrip<T = unknown>(
  payload: unknown
): Promise<T> {
  return apiFetch<T>("/api/trips", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export async function updateTrip<T = unknown>(
  tripId: string | number,
  payload: unknown
): Promise<T> {
  return apiFetch<T>(`/api/trips/${tripId}`, {
    method: "PUT",
    body: JSON.stringify(payload),
  });
}

export async function deleteTrip<T = unknown>(
  tripId: string | number
): Promise<T> {
  return apiFetch<T>(`/api/trips/${tripId}`, {
    method: "DELETE",
  });
}

/* -------------------------------------------------------------------------- */
/* Payments                                                                   */
/* -------------------------------------------------------------------------- */

export async function createCheckout<T = unknown>(
  payload: unknown
): Promise<T> {
  return apiFetch<T>("/api/payments/checkout", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

/* -------------------------------------------------------------------------- */
/* Contact                                                                    */
/* -------------------------------------------------------------------------- */

export async function sendContactMessage<T = unknown>(
  payload: unknown
): Promise<T> {
  return apiFetch<T>("/api/contact", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

