"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";

import { useAuth } from "@/components/auth/AuthProvider";
import { useAppConfig } from "@/components/RemoteConfigProvider";
import { getResolvedNavItems } from "@/types/remoteConfig";

export default function Navbar() {
  const pathname = usePathname();
  const router = useRouter();

  const [mobileOpen, setMobileOpen] = useState(false);

  const { user, logout, loading } = useAuth();

  const {
    remoteConfig,
    branding,
    geo,
    primaryColor,
  } = useAppConfig();

  /*
   * Navigation comes from the REAL remote
   * Technoheaven configuration.
   */
  const navItems = getResolvedNavItems(remoteConfig);

  const brandName =
    branding.name?.trim() || "";

  const brandLogo =
    branding.logo?.trim() || null;

  const ctaColor =
    primaryColor || "#64748b";

  const isActiveLink = (href: string) => {
    if (href === "/") {
      return pathname === "/";
    }

    return (
      pathname === href ||
      pathname.startsWith(`${href}/`)
    );
  };

  const ctaLabel = "Create Trip";

  const sharedLinkClassName = (
    active: boolean
  ) =>
    `nav-link ${
      active ? "nav-link-active" : ""
    }`.trim();

  const showLoggedIn =
    !loading && !!user;

  const headerClassName =
    "brand-navbar animate-nav-in";

  const ctaClassName =
    "navbar-cta";

  return (
    <header className={headerClassName}>
      <nav
        className="brand-navbar__inner flex min-h-16 w-full items-center gap-4 px-4 sm:px-6"
        aria-label="Main navigation"
      >
        {/* =====================================================
            BRAND / LOGO
            ===================================================== */}
        <Link
          href="/"
          className="brand-logo flex min-w-0 shrink-0 items-center gap-2"
          aria-label={
            brandName
              ? `${brandName} home page`
              : "Home page"
          }
          onClick={() => setMobileOpen(false)}
        >
          {brandLogo ? (
            <img
              src={brandLogo}
              alt={
                brandName ||
                "Website logo"
              }
              className="block h-10 w-auto max-w-[180px] shrink-0 object-contain sm:h-11 sm:max-w-[200px]"
            />
          ) : (
            <span className="brand-logo__mark flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-full">
              {brandName
                ? brandName
                    .charAt(0)
                    .toUpperCase()
                : ""}
            </span>
          )}

          {brandName && !brandLogo && (
            <span className="brand-logo__text max-w-[140px] truncate">
              {brandName}
            </span>
          )}
        </Link>

        {/* =====================================================
            DESKTOP NAVIGATION
            ===================================================== */}
        <div
          className="desktop-nav ml-2 hidden min-w-0 flex-1 items-center gap-5 lg:flex"
          aria-label="Primary navigation links"
        >
          {navItems.map((item) => {
            const active =
              isActiveLink(item.href);

            return (
              <Link
                key={`${item.href}-${item.label}`}
                href={item.href}
                className={`${sharedLinkClassName(
                  active
                )} brand-link whitespace-nowrap`}
                aria-current={
                  active ? "page" : undefined
                }
                onClick={() =>
                  setMobileOpen(false)
                }
              >
                {item.label}
              </Link>
            );
          })}
        </div>

        {/* =====================================================
            LOCATION
            ===================================================== */}
        {geo.countryName && (
          <div
            className="hidden shrink-0 items-center gap-1 rounded-full border border-slate-200/80 bg-white/70 px-2.5 py-1 text-xs font-medium text-slate-700 backdrop-blur-sm xl:inline-flex"
            title={
              geo.city
                ? `Detected Location: ${geo.city}, ${geo.countryName}`
                : `Detected Region: ${geo.countryName}`
            }
          >
            <span className="inline-block h-2 w-2 animate-pulse rounded-full bg-emerald-500" />

            <span className="max-w-[180px] truncate">
              {geo.displayLocation ??
                geo.countryName}
            </span>
          </div>
        )}

        {/* =====================================================
            DESKTOP AUTH ACTIONS
            ===================================================== */}
        <div className="ml-auto hidden shrink-0 items-center gap-3 lg:flex">
          {showLoggedIn ? (
            <>
              <span className="hidden text-sm font-medium text-slate-700 xl:inline">
                Hi,{" "}
                {user!.name
                  .split(" ")[0]}
              </span>

              <Link
                href="/trips"
                className="nav-link whitespace-nowrap"
              >
                Profile
              </Link>

              <Link
                href="/trips"
                className="nav-link whitespace-nowrap"
              >
                My Trips
              </Link>

              <button
                type="button"
                onClick={async () => {
                  await logout();
                  router.push("/login");
                }}
                className="whitespace-nowrap rounded-full border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 transition-colors hover:bg-slate-100"
              >
                Logout
              </button>
            </>
          ) : (
            <>
              <Link
                href="/login"
                className="nav-link whitespace-nowrap"
              >
                Login
              </Link>

              <Link
                href="/register"
                className="nav-link whitespace-nowrap"
              >
                Register
              </Link>

              <Link
                href="/trips/create"
                style={{
                  backgroundColor: ctaColor,
                }}
                className={`${ctaClassName} whitespace-nowrap`}
              >
                {ctaLabel}
              </Link>
            </>
          )}
        </div>

        {/* =====================================================
            MOBILE MENU BUTTON
            ===================================================== */}
        <button
          type="button"
          className="mobile-menu-toggle ml-auto shrink-0 lg:hidden"
          aria-label={
            mobileOpen
              ? "Close navigation menu"
              : "Open navigation menu"
          }
          aria-controls="mobile-navigation"
          aria-expanded={mobileOpen}
          onClick={() =>
            setMobileOpen(
              (open) => !open
            )
          }
        >
          <span />
          <span />
          <span />
        </button>
      </nav>

      {/* =======================================================
          MOBILE NAVIGATION
          ======================================================= */}
      {mobileOpen && (
        <div
          className="mobile-nav-panel"
          id="mobile-navigation"
          aria-label="Mobile navigation"
        >
          <div className="mobile-nav-panel__inner">
            {/* Location */}
            {geo.countryName && (
              <div className="mb-2 flex items-center gap-1.5 rounded-lg bg-slate-100 px-3 py-1.5 text-xs font-medium text-slate-600">
                <span className="inline-block h-2 w-2 animate-pulse rounded-full bg-emerald-500" />

                <span>
                  Location:{" "}
                  {geo.displayLocation ??
                    geo.countryName}
                </span>
              </div>
            )}

            {/* Remote navigation links */}
            {navItems.map((item) => {
              const active =
                isActiveLink(item.href);

              return (
                <Link
                  key={`${item.href}-${item.label}-mobile`}
                  href={item.href}
                  className={`${sharedLinkClassName(
                    active
                  )} brand-link`}
                  aria-current={
                    active ? "page" : undefined
                  }
                  onClick={() =>
                    setMobileOpen(false)
                  }
                >
                  {item.label}
                </Link>
              );
            })}

            {/* Mobile authentication */}
            {showLoggedIn ? (
              <>
                <span className="px-2 py-2 text-sm font-medium text-slate-700">
                  Hi,{" "}
                  {user!.name
                    .split(" ")[0]}
                </span>

                <Link
                  href="/trips"
                  className={sharedLinkClassName(
                    pathname ===
                      "/trips"
                  )}
                  onClick={() =>
                    setMobileOpen(false)
                  }
                >
                  Profile
                </Link>

                <Link
                  href="/trips"
                  className={sharedLinkClassName(
                    pathname ===
                      "/trips"
                  )}
                  onClick={() =>
                    setMobileOpen(false)
                  }
                >
                  My Trips
                </Link>

                <button
                  type="button"
                  onClick={async () => {
                    await logout();
                    setMobileOpen(false);
                    router.push(
                      "/login"
                    );
                  }}
                  className="rounded-full border border-slate-300 px-4 py-2 text-left text-sm font-medium text-slate-700 transition-colors hover:bg-slate-100"
                >
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link
                  href="/login"
                  className={sharedLinkClassName(
                    pathname ===
                      "/login"
                  )}
                  onClick={() =>
                    setMobileOpen(false)
                  }
                >
                  Login
                </Link>

                <Link
                  href="/register"
                  className={sharedLinkClassName(
                    pathname ===
                      "/register"
                  )}
                  onClick={() =>
                    setMobileOpen(false)
                  }
                >
                  Register
                </Link>

                <Link
                  href="/trips/create"
                  style={{
                    backgroundColor:
                      ctaColor,
                  }}
                  className={ctaClassName}
                  onClick={() =>
                    setMobileOpen(false)
                  }
                >
                  {ctaLabel}
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
}