"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";

import {
  apiFetch,
  fetchBrandConfig,
} from "@/lib/apiClient";

export type AuthUser = {
  id: string;
  name: string;
  email: string;
  brandId: string;
  brand: string;
  role?: string | null;
};

type AuthContextValue = {
  user: AuthUser | null;
  loading: boolean;
  login: (nextUser: AuthUser) => void;
  refreshUser: () => Promise<AuthUser | null>;
  logout: () => Promise<void>;
};

const AuthContext =
  createContext<AuthContextValue | null>(null);

const getBrandStorageKey = (
  brand?: string | null
) => {
  const brandKey =
    brand
      ?.trim()
      .toLowerCase()
      .replace(/\s+/g, "") || "default";

  return `travelapp_auth_${brandKey}`;
};

function isValidAuthUser(
  u: Partial<AuthUser> | null | undefined
): u is AuthUser {
  return (
    !!u?.id &&
    !!u?.email &&
    !!u?.name &&
    !!u?.brand
  );
}

function readStoredUser(): AuthUser | null {
  if (typeof window === "undefined") {
    return null;
  }

  try {
    const storagePrefix = "travelapp_auth_";

    for (
      let index = 0;
      index < window.localStorage.length;
      index++
    ) {
      const key = window.localStorage.key(index);

      if (
        !key ||
        !key.startsWith(storagePrefix)
      ) {
        continue;
      }

      const stored =
        window.localStorage.getItem(key);

      if (!stored) {
        continue;
      }

      const parsed =
        JSON.parse(stored) as Partial<AuthUser>;

      if (isValidAuthUser(parsed)) {
        return parsed;
      }

      window.localStorage.removeItem(key);
    }

    return null;
  } catch {
    return null;
  }
}

function persistUser(
  nextUser: AuthUser | null
) {
  if (typeof window === "undefined") {
    return;
  }

  const storagePrefix = "travelapp_auth_";
  const keysToRemove: string[] = [];

  for (
    let index = 0;
    index < window.localStorage.length;
    index++
  ) {
    const key = window.localStorage.key(index);

    if (
      key?.startsWith(storagePrefix)
    ) {
      keysToRemove.push(key);
    }
  }

  for (const key of keysToRemove) {
    window.localStorage.removeItem(key);
  }

  if (!nextUser) {
    return;
  }

  const key = getBrandStorageKey(
    nextUser.brand
  );

  window.localStorage.setItem(
    key,
    JSON.stringify(nextUser)
  );
}

/**
 * Gets the remote Technoheaven website ID.
 *
 * This is the value returned by:
 *
 * /api/proxy/brand-config?lang=en
 *
 * Example:
 * website.id = 2
 */
async function getRemoteWebsiteId(): Promise<number> {
  const config = await fetchBrandConfig();

  const websiteId =
    config.result?.website?.id;

  if (!websiteId) {
    throw new Error(
      "Remote website configuration is missing website.id."
    );
  }

  return websiteId;
}

export function AuthProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [user, setUser] =
    useState<AuthUser | null>(
      () => readStoredUser()
    );

  const [loading, setLoading] =
    useState(true);

  const login = useCallback(
    (nextUser: AuthUser) => {
      if (!isValidAuthUser(nextUser)) {
        setUser(null);
        persistUser(null);
        setLoading(false);
        return;
      }

      setUser(nextUser);
      persistUser(nextUser);
      setLoading(false);
    },
    []
  );

  const refreshUser =
    useCallback(async () => {
      try {
        const websiteId =
          await getRemoteWebsiteId();

        const response =
          await apiFetch<AuthUser>(
            "/api/auth/me",
            {
              headers: {
                "X-Brand":
                  String(websiteId),
              },
            }
          );

        if (!isValidAuthUser(response)) {
          setUser(null);
          persistUser(null);
          return null;
        }

        setUser(response);
        persistUser(response);

        return response;
      } catch {
        setUser(null);
        persistUser(null);

        return null;
      } finally {
        setLoading(false);
      }
    }, []);

  const logout =
    useCallback(async () => {
      try {
        const websiteId =
          await getRemoteWebsiteId();

        await apiFetch<{
          message: string;
        }>("/api/auth/logout", {
          method: "POST",
          headers: {
            "X-Brand":
              String(websiteId),
          },
        });
      } catch {
        // Ignore logout errors.
      }

      setUser(null);
      persistUser(null);
      setLoading(false);
    }, []);

  useEffect(() => {
    let isMounted = true;

    const loadUser = async () => {
      const storedUser =
        readStoredUser();

      if (
        storedUser &&
        isMounted
      ) {
        setUser(storedUser);
      }

      try {
        const websiteId =
          await getRemoteWebsiteId();

        const response =
          await apiFetch<AuthUser>(
            "/api/auth/me",
            {
              headers: {
                "X-Brand":
                  String(websiteId),
              },
            }
          );

        if (!isMounted) {
          return;
        }

        if (
          isValidAuthUser(response)
        ) {
          setUser(response);
          persistUser(response);
        } else {
          setUser(null);
          persistUser(null);
        }
      } catch {
        if (isMounted) {
          setUser(null);
          persistUser(null);
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    void loadUser();

    return () => {
      isMounted = false;
    };
  }, []);

  const value = useMemo(
    () => ({
      user,
      loading,
      login,
      refreshUser,
      logout,
    }),
    [
      user,
      loading,
      login,
      refreshUser,
      logout,
    ]
  );

  return (
    <AuthContext.Provider
      value={value}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context =
    useContext(AuthContext);

  if (!context) {
    throw new Error(
      "useAuth must be used within an AuthProvider"
    );
  }

  return context;
}