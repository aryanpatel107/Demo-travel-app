"use client";

import { useEffect, useState } from "react";
import { useAppConfig } from "@/components/RemoteConfigProvider";

const splashCopy: Record<string, { tag: string; accent: string }> = {
  wanderly: {
    tag: "Go somewhere unforgettable.",
    accent: "#f59e0b",
  },
  travelpro: {
    tag: "Professional travel. Simply done.",
    accent: "#60a5fa",
  },
  mytravel: {
    tag: "Your journey starts here.",
    accent: "#8b5cf6",
  },
};

export default function BrandSplash() {
  const [visible, setVisible] = useState(true);
  const appConfig = useAppConfig();

  const branding = appConfig?.branding;
  const brandName = branding?.name?.trim() || "";
  const brandKey = brandName.toLowerCase().replace(/\s+/g, "");

  const primaryColor = appConfig?.primaryColor || "#64748b";

  const current = splashCopy[brandKey] ?? {
    tag: "",
    accent: primaryColor,
  };

  const logo =
    branding?.logo?.trim() ||
    brandName.charAt(0).toUpperCase() ||
    "T";

  useEffect(() => {
    const timer = window.setTimeout(() => {
      setVisible(false);
    }, 1650);

    return () => {
      window.clearTimeout(timer);
    };
  }, []);

  if (!visible) {
    return null;
  }

  return (
    <div
      className="brand-splash fixed inset-0 z-[100] flex items-center justify-center overflow-hidden"
      style={{
        background: primaryColor,
      }}
      role="status"
      aria-live="polite"
      aria-label={`${brandName || "Travel"} startup splash`}
    >
      <div className="brand-splash__content flex flex-col items-center text-center">
        <div
          className="mb-5 flex h-20 w-20 items-center justify-center rounded-full text-2xl font-bold shadow-2xl"
          style={{
            background: primaryColor,
            color: "#fff",
            boxShadow: `0 0 35px ${primaryColor}70`,
          }}
        >
          {logo}
        </div>

        <div
          className="font-display text-4xl font-semibold tracking-tight"
          style={{
            color: "#fff",
          }}
        >
          {brandName || "Travel"}
        </div>

        {current.tag && (
          <div
            className="mt-3 text-sm uppercase tracking-[0.35em]"
            style={{
              color: current.accent,
            }}
          >
            {current.tag}
          </div>
        )}
      </div>
    </div>
  );
}