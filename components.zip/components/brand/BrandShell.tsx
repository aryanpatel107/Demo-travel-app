"use client";

import type { CSSProperties, ReactNode } from "react";
import { useAppConfig } from "@/components/RemoteConfigProvider";

interface BrandShellProps {
  children: ReactNode;
}

export default function BrandShell({ children }: BrandShellProps) {
  const { branding, primaryColor, secondaryColor } = useAppConfig();

  const brandName = branding.name?.trim() || "";
  const normalizedBrandName = brandName.toLowerCase();

  const theme = {
    "--brand-primary": primaryColor || "transparent",
    "--brand-secondary": secondaryColor || "transparent",
    "--brand-background": "transparent",
    "--brand-surface": "transparent",
    "--brand-text": "inherit",
    "--brand-muted": "inherit",
    "--brand-accent": primaryColor || "transparent",
  } as CSSProperties;

  const isWanderly = normalizedBrandName.includes("wanderly");

  return (
    <div
      data-brand={normalizedBrandName || "travel"}
      className={`brand-shell min-h-screen w-full${
        isWanderly ? " wanderly-page" : ""
      }`}
      style={theme}
    >
      {children}
    </div>
  );
}