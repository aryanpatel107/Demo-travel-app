"use client";

import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

import {
  getStaticBrandConfig,
  resolveRemoteBrandKey,
  type BrandName,
} from "@/config";
import type { BrandConfig } from "@/config/types";
import { fetchBrandConfig } from "@/lib/apiClient";

/* =========================================================
   Types
   ========================================================= */

type RemoteConfig = Record<string, unknown> | null;

interface BrandingInfo {
  name: string;
  fullName: string;
  logo: string;
  copyright: string;
}

interface GeoInfo {
  country: string | null;
  countryName: string | null;
  city: string | null;
  ip: string | null;
  displayLocation: string;
}

interface ContactItem {
  value: string;
}

interface ContactsInfo {
  emails: ContactItem[];
  phones: ContactItem[];
}

interface SocialItem {
  key: string;
  value: string;
  platform: string;
  url: string;
}

interface AppConfigContextValue {
  config: BrandConfig;
  remoteConfig: RemoteConfig;
  brandKey: BrandName | null;
  loading: boolean;
  error: string | null;
  branding: BrandingInfo;
  geo: GeoInfo;
  contacts: ContactsInfo;
  socials: SocialItem[];
  currencies: unknown[];
  defaultCurrency: unknown;
  recommendations: unknown[];
  modules: unknown[];
  primaryColor: string;
  secondaryColor: string;
}

const RemoteConfigContext = createContext<AppConfigContextValue | null>(null);

/* =========================================================
   Helpers
   ========================================================= */

const isStr = (v: unknown): v is string =>
  typeof v === "string" && v.trim().length > 0;

const firstStr = (...vals: unknown[]): string | undefined => {
  for (const v of vals) if (isStr(v)) return v.trim();
  return undefined;
};

const COUNTRY_NAMES: Record<string, string> = {
  IN: "India",
  MY: "Malaysia",
  US: "United States",
  GB: "United Kingdom",
  AE: "United Arab Emirates",
  SG: "Singapore",
  TH: "Thailand",
  ID: "Indonesia",
  AU: "Australia",
  CA: "Canada",
  DE: "Germany",
  FR: "France",
  IT: "Italy",
  ES: "Spain",
  JP: "Japan",
  CN: "China",
};

function getCountryName(code: string | null): string | null {
  if (!code) return null;
  const n = code.trim().toUpperCase();
  return COUNTRY_NAMES[n] ?? n;
}

function extractRemote(remote: RemoteConfig) {
  const website = (remote?.website as Record<string, unknown>) ?? {};
  const theme = (remote?.theme as Record<string, unknown>) ?? {};
  const colors =
    (theme?.colors as Record<string, unknown>) ??
    (theme?.color as Record<string, unknown>) ??
    (remote?.colors as Record<string, unknown>) ??
    {};

  return {
    name: firstStr(website.name, website.fullName, website.title, remote?.name),
    fullName: firstStr(website.fullName, website.name, website.title, remote?.fullName),
    logo: firstStr(
      website.logo,
      website.logoUrl,
      website.logoURL,
      website.image,
      website.icon,
      remote?.logo,
      theme.logo,
      theme.logoUrl,
    ),
    primary: firstStr(colors.primary, colors.primaryColor, colors.brandPrimary, remote?.primaryColor),
    secondary: firstStr(colors.secondary, colors.secondaryColor, colors.brandSecondary, remote?.secondaryColor),
    background: firstStr(colors.background, colors.backgroundColor),
    surface: firstStr(colors.surface, colors.surfaceColor),
    text: firstStr(colors.text, colors.textColor),
    mutedText: firstStr(colors.mutedText, colors.muted, colors.mutedColor),
    accent: firstStr(colors.accent, colors.accentColor),
    font: (() => {
      const f = remote?.font;
      if (!f) return undefined;
      if (isStr(f)) return { family: f.trim() };
      if (typeof f === "object" && f !== null) {
        const fontObj = f as Record<string, unknown>;
        const family = firstStr(fontObj.family, fontObj.name, fontObj.fontFamily);
        if (family) {
          return {
            family,
            files: Array.isArray(fontObj.files) ? fontObj.files : undefined,
          };
        }
      }
      return undefined;
    })(),
    copyright: (() => {
      const rights = remote?.websiteRights;
      if (Array.isArray(rights)) {
        for (const item of rights) {
          if (typeof item === "object" && item !== null) {
            const obj = item as Record<string, unknown>;
            const v = firstStr(obj.value, obj.text, obj.label, obj.name);
            if (v) return v;
          }
        }
      }
      return firstStr(remote?.copyright, website.copyright);
    })(),
    navigation: Array.isArray(website.navigation) ? website.navigation : undefined,
    modules: Array.isArray(remote?.websiteModules) ? remote.websiteModules : [],
    recommendations: Array.isArray(remote?.recommendations) ? remote.recommendations : [],
    currencies: Array.isArray(remote?.websiteCurrency) ? remote.websiteCurrency : [],
    socials: Array.isArray(remote?.socialMediaConfig)
      ? (remote.socialMediaConfig as unknown[])
          .map((item) => {
            const obj = (item ?? {}) as Record<string, unknown>;
            return {
              key: firstStr(obj.key, obj.name, obj.platform) ?? "",
              value: firstStr(obj.value, obj.url, obj.link) ?? "",
              platform: firstStr(obj.platform, obj.key, obj.name) ?? "",
              url: firstStr(obj.url, obj.value, obj.link) ?? "",
            };
          })
          .filter((s) => s.key || s.value || s.platform || s.url)
      : [],
    geo: (() => {
      const g = (remote?.geo as Record<string, unknown>) ?? {};
      const country = isStr(g.country) ? g.country.trim() : null;
      const city = isStr(g.city) ? g.city.trim() : null;
      const ip = isStr(g.ip) ? g.ip.trim() : null;
      const countryName = getCountryName(country);
      let displayLocation = "";
      if (city && countryName) displayLocation = `${city}, ${countryName}`;
      else if (countryName) displayLocation = countryName;
      else if (city) displayLocation = city;
      return { country, countryName, city, ip, displayLocation };
    })(),
    contacts: (() => {
      const raw = (remote?.websiteContact as Record<string, unknown>) ??
        (remote?.contact as Record<string, unknown>) ??
        {};
      const emails: ContactItem[] = [];
      const phones: ContactItem[] = [];

      const add = (list: ContactItem[], value: unknown) => {
        if (isStr(value) && !list.some((i) => i.value === value.trim())) {
          list.push({ value: value.trim() });
        }
      };

      if (Array.isArray(raw.emails)) {
        raw.emails.forEach((item) => {
          if (typeof item === "string") add(emails, item);
          else if (typeof item === "object" && item !== null) {
            const obj = item as Record<string, unknown>;
            add(emails, obj.value ?? obj.email ?? obj.address);
          }
        });
      }
      if (Array.isArray(raw.phones)) {
        raw.phones.forEach((item) => {
          if (typeof item === "string") add(phones, item);
          else if (typeof item === "object" && item !== null) {
            const obj = item as Record<string, unknown>;
            add(phones, obj.value ?? obj.phone ?? obj.number);
          }
        });
      }

      add(emails, raw.email);
      add(emails, raw.emailAddress);
      add(phones, raw.phone);
      add(phones, raw.phoneNumber);
      add(phones, raw.mobile);

      return { emails, phones };
    })(),
    hero: {
      badge: firstStr(
        (website.hero as Record<string, unknown>)?.badge,
        (remote?.hero as Record<string, unknown>)?.badge,
      ),
      title: firstStr(
        (website.hero as Record<string, unknown>)?.title,
        (remote?.hero as Record<string, unknown>)?.title,
      ),
      subtitle: firstStr(
        (website.hero as Record<string, unknown>)?.subtitle,
        (remote?.hero as Record<string, unknown>)?.subtitle,
      ),
      primaryCtaLabel: firstStr(
        (website.hero as Record<string, unknown>)?.primaryCtaLabel,
        (remote?.hero as Record<string, unknown>)?.primaryCtaLabel,
      ),
      secondaryCtaLabel: firstStr(
        (website.hero as Record<string, unknown>)?.secondaryCtaLabel,
        (remote?.hero as Record<string, unknown>)?.secondaryCtaLabel,
      ),
      primaryCtaHref: firstStr(
        (website.hero as Record<string, unknown>)?.primaryCtaHref,
        (remote?.hero as Record<string, unknown>)?.primaryCtaHref,
      ),
      secondaryCtaHref: firstStr(
        (website.hero as Record<string, unknown>)?.secondaryCtaHref,
        (remote?.hero as Record<string, unknown>)?.secondaryCtaHref,
      ),
    },
    splash: {
      title: firstStr(
        (website.splash as Record<string, unknown>)?.title,
        (remote?.splash as Record<string, unknown>)?.title,
      ),
      subtitle: firstStr(
        (website.splash as Record<string, unknown>)?.subtitle,
        (remote?.splash as Record<string, unknown>)?.subtitle,
      ),
    },
    metadata: {
      title: firstStr(website.fullName, website.name),
      description: firstStr(website.description, remote?.description),
    },
  };
}

function mergeBrandConfig(staticConfig: BrandConfig, remote: RemoteConfig): BrandConfig {
  const r = extractRemote(remote);

  return {
    ...staticConfig,
    name: r.name ?? staticConfig.name,
    logo: r.logo ?? staticConfig.logo,
    visualStyle: staticConfig.visualStyle,
    colors: {
      ...staticConfig.colors,
      primary: r.primary ?? staticConfig.colors.primary,
      secondary: r.secondary ?? staticConfig.colors.secondary,
      background: r.background ?? staticConfig.colors.background,
      surface: r.surface ?? staticConfig.colors.surface,
      text: r.text ?? staticConfig.colors.text,
      mutedText: r.mutedText ?? staticConfig.colors.mutedText,
      accent: r.accent ?? staticConfig.colors.accent,
    },
    navigation:
      r.navigation && r.navigation.length > 0 ? r.navigation : staticConfig.navigation,
    hero: {
      ...staticConfig.hero,
      badge: r.hero.badge ?? staticConfig.hero.badge,
      title: r.hero.title ?? staticConfig.hero.title,
      subtitle: r.hero.subtitle ?? staticConfig.hero.subtitle,
      primaryCtaLabel: r.hero.primaryCtaLabel ?? staticConfig.hero.primaryCtaLabel,
      secondaryCtaLabel: r.hero.secondaryCtaLabel ?? staticConfig.hero.secondaryCtaLabel,
      primaryCtaHref: r.hero.primaryCtaHref ?? staticConfig.hero.primaryCtaHref,
      secondaryCtaHref: r.hero.secondaryCtaHref ?? staticConfig.hero.secondaryCtaHref,
    },
    features: { ...staticConfig.features },
    sectionTitles: { ...staticConfig.sectionTitles },
    splash: {
      ...staticConfig.splash,
      title: r.splash.title ?? staticConfig.splash.title,
      subtitle: r.splash.subtitle ?? staticConfig.splash.subtitle,
      logo: r.logo ?? staticConfig.splash.logo,
      backgroundColor: r.primary ?? staticConfig.splash.backgroundColor,
      accentColor: r.secondary ?? staticConfig.splash.accentColor,
      animation: staticConfig.splash.animation,
    },
    metadata: {
      ...staticConfig.metadata,
      title: r.metadata.title ?? staticConfig.metadata.title,
      description: r.metadata.description ?? staticConfig.metadata.description,
    },
    contact: {
      ...staticConfig.contact,
      email: r.contacts.emails[0]?.value ?? staticConfig.contact.email,
      phone: r.contacts.phones[0]?.value ?? staticConfig.contact.phone,
    },
    font: r.font ?? staticConfig.font,
    websiteModules: r.modules.length > 0 ? r.modules : staticConfig.websiteModules,
    recommendations: r.recommendations.length > 0 ? r.recommendations : staticConfig.recommendations,
    socialMediaConfig: r.socials.length > 0 ? r.socials : staticConfig.socialMediaConfig,
    geo: remote?.geo ? r.geo : staticConfig.geo,
    websiteConfiguration: remote?.websiteConfiguration ?? staticConfig.websiteConfiguration,
    websiteCurrency: r.currencies.length > 0 ? r.currencies : staticConfig.websiteCurrency,
    websiteRights:
      Array.isArray(remote?.websiteRights) && (remote.websiteRights as unknown[]).length > 0
        ? remote.websiteRights
        : staticConfig.websiteRights,
    websiteLinks: remote?.websiteLinks ?? staticConfig.websiteLinks,
    theme: remote?.theme ?? staticConfig.theme,
    copyright: r.copyright ?? staticConfig.copyright,
  };
}

/* =========================================================
   Provider
   ========================================================= */

export function RemoteConfigProvider({ children }: { children: ReactNode }) {
  const [remoteConfig, setRemoteConfig] = useState<RemoteConfig>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      try {
        setLoading(true);
        setError(null);

        const res = await fetchBrandConfig("en");
        if (cancelled) return;

        if (!res?.isSuccess) {
          throw new Error(res?.error ?? "Unable to load website configuration.");
        }

        setRemoteConfig((res?.result as RemoteConfig) ?? null);
      } catch (err) {
        if (cancelled) return;
        const msg = err instanceof Error ? err.message : "Unable to load website configuration.";
        console.error("Remote configuration error:", err);
        setError(msg);
        setRemoteConfig(null);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, []);

  const brandKey = useMemo<BrandName | null>(() => {
    const name = extractRemote(remoteConfig).name;
    return name ? resolveRemoteBrandKey(name) : null;
  }, [remoteConfig]);

  const resolvedBrandKey = brandKey ?? "travelpro";

  const staticConfig = useMemo(
    () => getStaticBrandConfig(resolvedBrandKey),
    [resolvedBrandKey],
  );

  const config = useMemo(
    () => mergeBrandConfig(staticConfig, remoteConfig),
    [staticConfig, remoteConfig],
  );

  const branding = useMemo<BrandingInfo>(() => {
    const r = extractRemote(remoteConfig);
    return {
      name: r.name ?? config.name ?? staticConfig.name,
      fullName: r.fullName ?? config.name ?? staticConfig.name,
      logo: r.logo ?? config.logo ?? staticConfig.logo,
      copyright: r.copyright ?? config.copyright ?? "",
    };
  }, [remoteConfig, config, staticConfig]);

  const geo = useMemo(() => extractRemote(remoteConfig).geo, [remoteConfig]);

  const contacts = useMemo(() => {
    const remoteContacts = extractRemote(remoteConfig).contacts;
    const emails = [...remoteContacts.emails];
    const phones = [...remoteContacts.phones];

    if (emails.length === 0 && isStr(config.contact?.email)) {
      emails.push({ value: config.contact.email.trim() });
    }
    if (phones.length === 0 && isStr(config.contact?.phone)) {
      phones.push({ value: config.contact.phone.trim() });
    }

    return { emails, phones };
  }, [remoteConfig, config.contact]);

  const socials = useMemo(() => extractRemote(remoteConfig).socials, [remoteConfig]);

  const currencies = useMemo(
    () => (Array.isArray(config.websiteCurrency) ? config.websiteCurrency : []),
    [config.websiteCurrency],
  );

  const defaultCurrency = useMemo(() => {
    if (currencies.length > 0) {
      const preferred = currencies.find((c) => {
        if (typeof c !== "object" || c === null) return false;
        const obj = c as Record<string, unknown>;
        const code = obj.code ?? obj.currencyCode ?? obj.value ?? obj.name;
        return typeof code === "string" && code.toLowerCase() === "usd";
      });
      return preferred ?? currencies[0];
    }
    return remoteConfig?.defaultCurrency ?? remoteConfig?.currency ?? null;
  }, [currencies, remoteConfig]);

  const recommendations = useMemo(
    () => (Array.isArray(config.recommendations) ? config.recommendations : []),
    [config.recommendations],
  );

  const modules = useMemo(
    () => (Array.isArray(config.websiteModules) ? config.websiteModules : []),
    [config.websiteModules],
  );

  const primaryColor = config.colors?.primary || "#64748b";
  const secondaryColor = config.colors?.secondary || "#94a3b8";

  // Apply CSS variables
  useEffect(() => {
    if (typeof document === "undefined") return;

    const root = document.documentElement;
    root.style.setProperty("--brand-primary", primaryColor);
    root.style.setProperty("--brand-secondary", secondaryColor);

    if (config.colors?.background) root.style.setProperty("--brand-background", config.colors.background);
    if (config.colors?.surface) root.style.setProperty("--brand-surface", config.colors.surface);
    if (config.colors?.text) root.style.setProperty("--brand-text", config.colors.text);
    if (config.colors?.mutedText) root.style.setProperty("--brand-muted", config.colors.mutedText);
    if (config.colors?.accent) root.style.setProperty("--brand-accent", config.colors.accent);
    if (config.font?.family) root.style.setProperty("--brand-font-family", config.font.family);

    root.dataset.brand = brandKey ?? resolvedBrandKey;
  }, [config, primaryColor, secondaryColor, brandKey, resolvedBrandKey]);

  const value = useMemo<AppConfigContextValue>(
    () => ({
      config,
      remoteConfig,
      brandKey,
      loading,
      error,
      branding,
      geo,
      contacts,
      socials,
      currencies,
      defaultCurrency,
      recommendations,
      modules,
      primaryColor,
      secondaryColor,
    }),
    [
      config,
      remoteConfig,
      brandKey,
      loading,
      error,
      branding,
      geo,
      contacts,
      socials,
      currencies,
      defaultCurrency,
      recommendations,
      modules,
      primaryColor,
      secondaryColor,
    ],
  );

  return (
    <RemoteConfigContext.Provider value={value}>
      {children}
    </RemoteConfigContext.Provider>
  );
}

/* =========================================================
   Hooks
   ========================================================= */

export function useAppConfig() {
  const ctx = useContext(RemoteConfigContext);
  if (!ctx) {
    throw new Error("useAppConfig must be used inside RemoteConfigProvider.");
  }
  return ctx;
}

/** Backward-compatible alias */
export function useRemoteConfig() {
  return useAppConfig();
}